import React,{useState} from 'react';
import { FaXmark, FaCheck } from "react-icons/fa6";

const EdgeEditPopup = ({ edge, onClose, onSave }) => {
         <h1>testttttt</h1>

  return 
  
};



export default EdgeEditPopup;


