const Tab1  = ({id}) => {
          console.log(id,"nodedetails");
          return <h1>Nodedeatails:{id}</h1>
}
export default Tab1