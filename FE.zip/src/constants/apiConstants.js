export const BASE_URL = "http://localhost:5001"
// export const BASE_URL = "http://taxonanalyticatest.ap-south-1.elasticbeanstalk.com"