// import ShovelNodesView from "../component/shovelNodesView"
import DashboardLayout from "../layout/dashboard"
import ShowRoutes from "../component/showRoutes"
// import HomeComponent from "../component/showNodes"
// import Sidebar from "../component/sideBar"


const SampleView = () => {

    return <DashboardLayout>
        <ShowRoutes/>
        {/* <HomeComponent/> */}
    </DashboardLayout>
}

export default SampleView